define([], function() {
  return function() {
    return '?--dontmin';
  }
});
