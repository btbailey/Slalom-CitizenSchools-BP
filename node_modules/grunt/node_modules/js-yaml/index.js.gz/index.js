module.exports = require('./lib/js-yaml.js');
