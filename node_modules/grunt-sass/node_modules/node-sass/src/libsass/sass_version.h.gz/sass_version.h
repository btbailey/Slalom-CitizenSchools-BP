#ifndef SASS_VERSION_H
#define SASS_VERSION_H

#ifndef LIBSASS_VERSION
#define LIBSASS_VERSION "[NA]"
#endif

#endif
