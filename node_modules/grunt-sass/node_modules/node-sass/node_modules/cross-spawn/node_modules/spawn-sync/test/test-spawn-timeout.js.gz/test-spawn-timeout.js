setTimeout(function () {
  // staying alive
}, 60000);