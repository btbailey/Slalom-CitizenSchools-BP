module.exports = require('./wrapperConcat');
