node bin/build-acorn.js
node bin/without_eval > dist/acorn_csp.js
