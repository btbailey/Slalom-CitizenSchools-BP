
1.0.4 / 2012-09-17 
==================

  * fix keyframes float percentages
  * fix an issue with comments containing slashes.

1.0.3 / 2012-09-01 
==================

  * add component support
  * fix unquoted data uris [rstacruz]
  * fix keyframe names with no whitespace [rstacruz]
  * fix excess semicolon support [rstacruz]

1.0.2 / 2012-09-01 
==================

  * fix IE property hack support [rstacruz]
  * fix quoted strings in declarations [rstacruz]

1.0.1 / 2012-07-26 
==================

  * change "selector" to "selectors" array

1.0.0 / 2010-01-03
==================

  * Initial release
