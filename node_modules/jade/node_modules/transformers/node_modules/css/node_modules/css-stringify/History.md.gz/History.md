
1.0.5 / 2013-03-15 
==================

  * fix indentation of multiple selectors in @media. Closes #11

1.0.4 / 2012-11-15 
==================

  * fix indentation

1.0.3 / 2012-09-04 
==================

  * add __@charset__ support [rstacruz]

1.0.2 / 2012-09-01 
==================

  * add component support

1.0.1 / 2012-07-26 
==================

  * add "selectors" array support

0.0.1 / 2010-01-03
==================

  * Initial release
