function run_test() {
  runSourceMapTests('{THIS_MODULE}', do_throw);
}
